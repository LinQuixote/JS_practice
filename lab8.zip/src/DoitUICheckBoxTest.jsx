import React from 'react';
import CheckBox from './doit-ui/CheckBox';

const App = () => {
  const [state, setState] = React.useState({name77: true});
  const checkStatus = (name, value) => {
    setState({[name]: value});
  }

  return (
    <div>
      <CheckBox name="name" />
      <CheckBox name="name" label="이름" />
      <CheckBox name="name" label="이름" />
      <CheckBox name="name77" label="이름77" checked={state.name77} onChange={checkStatus} />
      <CheckBox name="name" label="이름" errorMessage="이름을 입력해주세요" />
      <CheckBox name="name" label="이름" autoFocus />
    </div>
  );
}

export default App;
