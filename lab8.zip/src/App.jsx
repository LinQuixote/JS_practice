import React from 'react';
import './App.css';
import MyForm from './CoinForm.jsx';
//import MyForm from './PizzaOrderForm.jsx';

const App = () => {
    return (
      <div>
        <MyForm />
      </div>
    );
}

export default App;
