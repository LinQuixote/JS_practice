import React from 'react';
import Radio from './ui/Radio';

const App = () => {
  const [state, setState] = React.useState({});
  const checkStatus = (name, value) => {
    setState({[name]: value});
  }

  return (
    <div>
      <Radio name="rad" label="이름1" value="rad1" cur={state.rad} onChange={checkStatus} />
      <Radio name="rad" label="이름2" value="rad2" cur={state.rad} onChange={checkStatus} />
      <Radio name="rad" label="이름3" value="rad3" cur={state.rad} onChange={checkStatus} autoFocus />
    </div>
  );
}

export default App;
